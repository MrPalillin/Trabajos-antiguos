package Resource;

/**
 * @author Daniel de Vicente Garrote(dandevi)
 * @author Sergio Motrel Bajo(sermotr)
 */

public interface Resource {

	/**
	 * Establece un factor de corrección a la fianza según el tipo de bici/pack
	 * a escoger
	 * 
	 * @param deposit
	 *            Fianza inicial
	 * @return Fianza modificada,que será un numero positivo mayor que cero
	 */

	double getDepositToPay(double deposit);

}

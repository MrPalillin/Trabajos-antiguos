package Bike;

import Resource.Resource;

/**
 * @author Daniel de Vicente Garrote(dandevi)
 * @author Sergio Motrel Bajo(sermotr)
 */

public abstract class Bike implements Resource {

	private final String talla, id, marca, modelo;
	private final double peso;
	private final int numPinones, numPlatos;

	/**
	 * Constructor de la clase abstracta Bike
	 * 
	 * @param talla
	 *            Talla de bici,difieren según el tipo de bici
	 * @param id
	 *            Identificador de bici
	 * @param marca
	 *            Marca de la bici
	 * @param modelo
	 *            Modelo de la bici
	 * @param peso
	 *            Peso de la bici,que es un número real mayor que cero
	 * @param numPinones
	 *            Nº de pinones de la bici(numero entero mayor o igual que 1)
	 * @param numPlatos
	 *            Nº de platos de la bici(numero entero mayor o igual que 1)
	 * 
	 * @see Resource
	 */

	public Bike(String talla, String id, String marca, String modelo, double peso, int numPinones, int numPlatos) {
		this.talla = talla;
		this.id = id;
		this.marca = marca;
		this.modelo = modelo;
		this.peso = peso;
		this.numPinones = numPinones;
		this.numPlatos = numPlatos;
		assert (peso > 0);
		assert (numPinones >= 1);
		assert (numPlatos >= 1);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bike other = (Bike) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (marca == null) {
			if (other.marca != null)
				return false;
		} else if (!marca.equals(other.marca))
			return false;
		if (modelo == null) {
			if (other.modelo != null)
				return false;
		} else if (!modelo.equals(other.modelo))
			return false;
		if (numPinones != other.numPinones)
			return false;
		if (numPlatos != other.numPlatos)
			return false;
		if (Double.doubleToLongBits(peso) != Double.doubleToLongBits(other.peso))
			return false;
		if (talla == null) {
			if (other.talla != null)
				return false;
		} else if (!talla.equals(other.talla))
			return false;
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Bike [talla=" + talla + ", id=" + id + ", marca=" + marca + ", modelo=" + modelo + ", peso=" + peso
				+ ", numPinones=" + numPinones + ", numPlatos=" + numPlatos + "]";
	}

	/**
	 * Establece un factor de corrección a la fianza según el tipo de bici a
	 * escoger
	 * 
	 * @param deposit
	 *            Fianza inicial
	 * @return Fianza modificada,que será un numero positivo mayor que cero
	 */

	@Override
	public abstract double getDepositToPay(double deposit);

	/**
	 * Getter de talla
	 * 
	 * @return talla de bici,los tipos dependen del tipo de bici
	 */

	public String getTalla() {
		return talla;
	}

	/**
	 * Getter del identificador
	 * 
	 * @return identificador de bicicleta
	 */

	public String getId() {
		return id;
	}

	/**
	 * Getter de marca
	 * 
	 * @return marca de la bicicleta
	 */

	public String getMarca() {
		return marca;
	}

	/**
	 * Getter de modelo
	 * 
	 * @return modelo de la bicicleta
	 */

	public String getModelo() {
		return modelo;
	}

	/**
	 * Getter del peso
	 * 
	 * @return peso de la bicicleta,que es un número real mayor que cero
	 */

	public double getPeso() {
		return peso;
	}

	/**
	 * Getter del número de pinones
	 * 
	 * @return Nº de pinones de la bicicleta(numero entero mayor o igual que 1)
	 */

	public int getNumPinones() {
		return numPinones;
	}

	/**
	 * Getter del numero de platos
	 * 
	 * @return Nº de platos de la bicicleta(numero entero mayor o igual que 1)
	 */

	public int getNumPlatos() {
		return numPlatos;
	}

}

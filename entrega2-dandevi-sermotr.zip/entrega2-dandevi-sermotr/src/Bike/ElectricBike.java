package Bike;

public class ElectricBike extends AdultBike {

	private final double parMotor;
	private final double voltaje;
	private final double carga;

	/**
	 * Constructor de la bici electrica(todas las bicis electricas son de
	 * adulto)
	 * 
	 * @param talla
	 *            Talla de bici
	 * @param id
	 *            Identificado de bici
	 * @param marca
	 *            Marca de la bici
	 * @param modelo
	 *            Modelo de bici
	 * @param peso
	 *            Peso de la bici en kilogramos
	 * @param numPinones
	 *            Numero de pinones de la bici
	 * @param numPlatos
	 *            Nimero de platos de la bici
	 * @param parMotor
	 *            Par motor de la bici en Newtons por metro
	 * @param voltaje
	 *            Voltaje de la bici en Amperios por hora
	 * @param carga
	 *            Carga de la bici en Vatios por hora
	 * @see Bike
	 */

	public ElectricBike(String talla, String id, String marca, String modelo, double peso, int numPinones,
			int numPlatos, double parMotor, double voltaje, double carga) {
		super(talla, id, marca, modelo, peso, numPinones, numPlatos);
		this.parMotor = parMotor;
		this.voltaje = voltaje;
		this.carga = carga;
		assert (parMotor > 0 && voltaje > 0 && carga > 0);
	}

	/**
	 * Obtiene la fianza para bicis electricas,que es mayor que la estandar y
	 * varía en funcion del voltaje
	 * 
	 * @see Resource
	 * @return fianza para bicis electricas
	 */

	@Override
	public double getDepositToPay(double deposit) {
		return deposit * (1 + (voltaje / 100));
	}

	/**
	 * Getter del par motor
	 * 
	 * @return Par motor de la bici,expresado en Newtons por metro(Nm)
	 */

	public double getParMotor() {
		return parMotor;
	}

	/**
	 * Getter del voltaje de la bici
	 * 
	 * @return Voltaje de la bici,expresado en voltios(V)
	 */

	public double getVoltaje() {
		return voltaje;
	}

	/**
	 * Getter de la carga de la bici electrica
	 * 
	 * @return Carga electrica de la bici,expresada en AmperiosHora(Ah)
	 */

	public double getCarga() {
		return carga;
	}

	/**
	 * Getter de la energia de la bici
	 * 
	 * @return Energia electrica de la bici,expresada en Vatios-hora(Wh=V*Ah)
	 */

	public double getBateria() {
		return (voltaje * carga);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		ElectricBike other = (ElectricBike) obj;
		if (Double.doubleToLongBits(carga) != Double.doubleToLongBits(other.carga))
			return false;
		if (Double.doubleToLongBits(parMotor) != Double.doubleToLongBits(other.parMotor))
			return false;
		if (Double.doubleToLongBits(voltaje) != Double.doubleToLongBits(other.voltaje))
			return false;
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ElectricBike [talla=" + super.getTalla() + ", id=" + super.getId() + ", marca=" + super.getMarca() + ", modelo=" + super.getModelo() + ", peso=" + super.getPeso()
		+ ", numPinones=" + super.getNumPinones() + ", numPlatos=" + super.getNumPlatos() + "parMotor=" + parMotor + ", voltaje=" + voltaje + ", carga=" + carga + "]";
	}
}

package Bike;

public class ChildBike extends Bike {

	/**
	 * Constructor de bici adulta
	 * 
	 * @param talla
	 *            Las tallas disponibles para ChildBike son numeros pares entre
	 *            12 y 26
	 *            
	 * @param id
	 *            Identificador de bici
	 * @param marca
	 *            Marca de la bici
	 * @param modelo
	 *            Modelo de la bici
	 * @param peso
	 *            Peso de la bici,que es un número real mayor que cero
	 * @param numPinones
	 *            Nº de pinones de la bici(numero entero mayor o igual que 1)
	 * @param numPlatos
	 *            Nº de platos de la bici(numero entero mayor o igual que 1)
	 * @see Bike
	 */

	public ChildBike(String talla, String id, String marca, String modelo, double peso, int numPinones, int numPlatos) {
		super(talla, id, marca, modelo, peso, numPinones, numPlatos);
		assert (Integer.parseInt(talla) % 2 == 0 && Integer.parseInt(talla) <= 26 && Integer.parseInt(talla) >= 12);
	}

	/**
	 * Obtiene la fianza para bicis de ninos,que es un 15 por ciento menor de la
	 * estandar
	 * 
	 * @see Resource
	 * @return finaza para bicis de nino(85% de la estandar)
	 */

	@Override
	public double getDepositToPay(double deposit) {
		return deposit * 0.85;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ChildBike [talla=" + super.getTalla() + ", id=" + super.getId() + ", marca=" + super.getMarca() + ", modelo=" + super.getModelo() + ", peso=" + super.getPeso()
		+ ", numPinones=" + super.getNumPinones() + ", numPlatos=" + super.getNumPlatos() + "]";
	}
}

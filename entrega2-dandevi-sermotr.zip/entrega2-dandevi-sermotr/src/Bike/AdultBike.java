package Bike;

/**
 * @author Daniel de Vicente Garrote(dandevi)
 * @author Sergio Motrel Bajo(sermotr)
 */

public class AdultBike extends Bike {

	/**
	 * Constructor de bici adulta
	 * 
	 * @param talla
	 *            Las tallas disponibles para AdultBike son S,M,L y XL     
	 * @param id
	 *            Identificador de bici
	 * @param marca
	 *            Marca de la bici
	 * @param modelo
	 *            Modelo de la bici
	 * @param peso
	 *            Peso de la bici,que es un número real mayor que cero
	 * @param numPinones
	 *            Nº de pinones de la bici(numero entero mayor o igual que 1)
	 * @param numPlatos
	 *            Nº de platos de la bici(numero entero mayor o igual que 1)
	 *            
	 * @see Bike
	 */

	public AdultBike(String talla, String id, String marca, String modelo, double peso, int numPinones, int numPlatos) {
		super(talla, id, marca, modelo, peso, numPinones, numPlatos);
		assert (talla.equals("S") || talla.equals("M") || talla.equals("L") || talla.equals("XL"));

	}

	/**
	 * Obtiene la fianza para bicis de adultos,que es la tarifa estadar
	 * 
	 * @see Resource
	 * @return fianza para bicis de adulto
	 */

	@Override
	public double getDepositToPay(double deposit) {
		return deposit;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AdultBike [talla=" + super.getTalla() + ", id=" + super.getId() + ", marca=" + super.getMarca() + ", modelo=" + super.getModelo() + ", peso=" + super.getPeso()
				+ ", numPinones=" + super.getNumPinones() + ", numPlatos=" + super.getNumPlatos() + "]";
	}
}

/**
 * 
 * @author Daniel de Vicente Garrote(dandevi)
 * @author Sergio Motrel Bajo(sermotr)
 *
 */

package CityBikeSystem;

import java.util.ArrayList;
import CityBikeParkingPoint.CityBikeParkingPoint;

public class CityBikeSystem {

	private ArrayList<CityBikeParkingPoint> aPuntos = new ArrayList<CityBikeParkingPoint>();
	private static double fianza;

	/**
	 * Constructor del sistema de puntos de aparcamiento
	 * 
	 * @param aPuntos
	 *            Lista de puntos de aparcamiento del sistema
	 * @param fianza
	 *            Fianza aplicada a todos los puntos del sistema
	 */

	public CityBikeSystem(ArrayList<CityBikeParkingPoint> aPuntos, double fianza) {

		this.aPuntos = aPuntos;
		this.fianza = fianza;

	}

	/**
	 * Devuelve la cantidad de puntos existentes en el sistema
	 * 
	 * @return La lista de puntos de aparcamiento
	 */

	public ArrayList<CityBikeParkingPoint> getAPuntos() {
		return aPuntos;
	}

	/**
	 * Anade un nuevo punto de aparcamiento al sistema
	 * 
	 * @param punto
	 *            Punto de aparcamiento a anadir
	 */

	public void nuevoPunto(CityBikeParkingPoint punto) {
		aPuntos.add(punto);

	}

	/**
	 * Borra un punto de aparcamiento existente del sistema(no realiza cambios
	 * si dicho punto no existe)
	 * 
	 * @param buscaId
	 *            ID del punto de aparcamiento a borrar
	 */

	public void borraPunto(Integer buscaId) {
		for (int i = 0; i < this.aPuntos.size(); i++) {
			if (this.aPuntos.get(i).getId() == buscaId) {
				aPuntos.remove(this.aPuntos.get(i));
			}
		}
	}

	/**
	 * Modifica la fianza existente del sistema de aparcamientos
	 * 
	 * @param nuevaFianza
	 *            Nueva fianza a anadir
	 */

	public void modFianza(double nuevaFianza) {
		assert (nuevaFianza > 0);
		this.fianza = nuevaFianza;
	}

	/**
	 * Devuelve la fianza del sistema
	 * 
	 * @return La fianza,un valor entero positivo mayor que cero
	 */

	public static double getFianza() {
		return fianza;
	}

	/**
	 * Devuelve la lista de puntos de aparcamiento con bicis disponibles
	 * 
	 * @return Lista de puntos de aparcamiento con bicis(puede ser null si no
	 *         hay ninguna)
	 */

	public CityBikeParkingPoint[] puntosConBici() {
		ArrayList<CityBikeParkingPoint> todos = new ArrayList<CityBikeParkingPoint>();
		for (int i = 0; i < this.aPuntos.size(); i++) {

			if (this.aPuntos.get(i).anclajesUsados() > 0) {
				todos.add(this.aPuntos.get(i));
			}

		}

		CityBikeParkingPoint[] array = todos.toArray(new CityBikeParkingPoint[1]);
		return array;

	}

	/**
	 * Devuelve la lista de puntos de aparcamiento con anclajes libres(sin
	 * bicis)
	 * 
	 * @return Lista de puntos de aparcamiento con anclajes libres(puede ser
	 *         null si no h)
	 */

	public CityBikeParkingPoint[] puntosLibres() {
		ArrayList<CityBikeParkingPoint> todos = new ArrayList<CityBikeParkingPoint>();
		for (CityBikeParkingPoint punto : aPuntos) {

			if (punto.anclajesUsados() < punto.numeroAnclajes()) {
				todos.add(punto);
			}

		}

		CityBikeParkingPoint[] array = todos.toArray(new CityBikeParkingPoint[1]);
		return array;

	}

	/**
	 * Método que calcula la distancia de dos puntos en formato decimal
	 * 
	 * @param gd2
	 *            Posicion numero uno
	 * @param gd1
	 *            Posicion numero dos
	 * @return Distancia en kilometros del punto especificado
	 */

	private double distGD(double[] gd2, double[] gd1) {
		double gdRes = 0;
		double a = 0;
		double c = 0;
		double dlat = Math.abs(gd2[1] - gd1[1]);
		dlat = Math.toRadians(dlat);

		double dlon = Math.abs(gd2[0] - gd1[0]);
		double r = 6371;
		dlon = Math.toRadians(dlon);

		a = (Math.sin(Math.pow((dlat / 2), 2)))
				+ Math.cos(gd1[1]) * Math.cos(gd2[1]) * (Math.sin(Math.pow(dlon / 2, 2)));
		c = 2 * Math.asin((Math.min(1, Math.sqrt(a))));
		gdRes = r * c;

		return gdRes;

	}

	/**
	 * Devuelve la lista de puntos de aparcamiento que se encuentren dentro de
	 * un radio dado en una posicion concreta
	 * 
	 * @param radio
	 *            Distancia máxima a la que busca el método
	 * @param coord
	 *            Punto desde el que se busca otros puntos de aparcamiento
	 * @return Lista de puntos de aparcamiento a una distancia igual o menor a
	 *         la indicada
	 */

	// latitud coord[1], longitud coord[0]
	public ArrayList<CityBikeParkingPoint> puntoEnRadio(double radio, double[] coord) {
		ArrayList<CityBikeParkingPoint> todos = new ArrayList<CityBikeParkingPoint>();
		for (CityBikeParkingPoint punto : aPuntos) {

			double[] puntoArray = { punto.getPosicionGD().getLon(), punto.getPosicionGD().getLat() };

			double distancia = Math.round(distGD(coord, puntoArray));
			if (distancia <= radio) {
				todos.add(punto);
			}

		}

		return todos;

	}
}
/**
 * 
 * @author Daniel de Vicente Garrote(dandevi)
 * @author Sergio Motrel Bajo(sermotr)
 *
 */

package Coordenadas;

import java.util.ArrayList;

public class Coordenadas {

	private double lat;
	private double lon;

	/**
	 * Constructor de la clase coordenadas con grados decimales
	 * 
	 * @param lat
	 *            Latitud
	 * @param lon
	 *            Longitud
	 */

	public Coordenadas(double lat, double lon) {
		this.lat = lat;
		this.lon = lon;
	}

	/**
	 * Constructor de la clase Coordenadas con grados sexagesimales
	 * 
	 * @param norteSur
	 *            Direccion Norte o Sur
	 * @param gradosNS
	 *            Grados Latitud
	 * @param minutosNS
	 *            Minutos Latitud
	 * @param segundosNS
	 *            Segundos Latitud
	 * @param esteOeste
	 *            Direccion Este u Oeste
	 * @param gradosEO
	 *            Grado Longitud
	 * @param minutosEO
	 *            Minutos Longitud
	 * @param segundosEO
	 *            Segundos Longitud
	 */

	public Coordenadas(char norteSur, double gradosNS, double minutosNS, double segundosNS, char esteOeste,
			double gradosEO, double minutosEO, double segundosEO) {

		this.lat = GMSAGDLat(norteSur, gradosNS, minutosNS, segundosNS);
		this.lon = GMSAGDLon(esteOeste, gradosEO, minutosEO, segundosEO);
	}

	/**
	 * Devuelve las coordenadas en formato GMS
	 * 
	 * @return Coordenadas en formato GMS
	 */

	public ArrayList<?> GDAGMS() {
		ArrayList<Object> gms = new ArrayList<Object>();
		double gradNS = Math.floor(Math.abs(lat));
		gms.add(gradNS);
		double tmpNS1 = Math.abs(Math.abs(lat) - Math.floor(Math.abs(lat))) * 60;
		double minNS = Math.floor(tmpNS1);
		gms.add(minNS);
		double tmpNS2 = Math.abs(tmpNS1 - minNS) * 60;
		double segNS = Math.floor(tmpNS2);
		gms.add(segNS);
		char norteSur = (lat >= 0) ? 'N' : 'S';
		gms.add(norteSur);

		double gradEO = Math.floor(Math.abs(lon));
		gms.add(gradEO);
		double tmpEO1 = Math.abs(Math.abs(lon) - Math.floor(Math.abs(lon))) * 60;
		double minEO = Math.floor(tmpEO1);
		gms.add(minEO);
		double tmpEO2 = Math.abs(tmpEO1 - minEO) * 60;
		double segEO = Math.floor(tmpEO2);
		gms.add(segEO);
		char esteOeste = (lon >= 0) ? 'E' : 'O';
		gms.add(esteOeste);
		return gms;
	}

	/**
	 * Transforma los grados sexagesimales de Norte/Sur a decimales de Latitud
	 * 
	 * @param norteSur
	 *            Direccion
	 * @param gradosNS
	 *            Grados
	 * @param minutosNS
	 *            Minutos
	 * @param segundosNS
	 *            Segundos
	 * @return Grados latitud(en GD)
	 */

	public double GMSAGDLat(char norteSur, double gradosNS, double minutosNS, double segundosNS) {
		double lat = (norteSur == 'N') ? (gradosNS + minutosNS / 60 + segundosNS / 3600)
				: -(gradosNS + minutosNS / 60 + segundosNS / 3600);
		return lat;
	}

	/**
	 * Transforma los grados sexagesimales de Este/Oeste a decimales de Longitud
	 * 
	 * @param esteOeste
	 *            Direccion
	 * @param gradosEO
	 *            Grados
	 * @param minutosEO
	 *            Minutos
	 * @param segundosEO
	 *            Segundos
	 * @return Grados longitud(en GD)
	 */

	public double GMSAGDLon(char esteOeste, double gradosEO, double minutosEO, double segundosEO) {
		double lon = (esteOeste == 'E') ? (gradosEO + minutosEO / 60 + segundosEO / 3600)
				: -(gradosEO + minutosEO / 60 + segundosEO / 3600);
		return lon;
	}

	/**
	 * Getter de latitud
	 * 
	 * @return Latitud
	 */

	public double getLat() {
		return lat;
	}

	/**
	 * Getter de longitud
	 * 
	 * @return Longitud
	 */

	public double getLon() {
		return lon;
	}

	/**
	 * Getter de los grados N/S
	 * 
	 * @return Grados N/S
	 */

	public double getGradosNS() {
		return (double) this.GDAGMS().get(0);
	}

	/**
	 * Getter de los minutos N/S
	 * 
	 * @return Minutos N/S
	 */

	public double getMinutosNS() {
		return (double) this.GDAGMS().get(1);
	}

	/**
	 * Getter de los Segundos N/S
	 * 
	 * @return Segudnos N/S
	 */

	public double getSegundosNS() {
		return (double) this.GDAGMS().get(2);
	}

	/**
	 * Getter de la direccion latitudinal(puede ser Norte o Sur)
	 * 
	 * @return Dreccion Latitudinal(solo puede ser N ó S)
	 */

	public char getNorteSur() {
		return (char) this.GDAGMS().get(3);
	}

	/**
	 * Getter de los grados E/O
	 * 
	 * @return Grados E/O
	 */

	public double getGradosEO() {
		return (double) this.GDAGMS().get(4);
	}

	/**
	 * Getter de los minutos E/O
	 * 
	 * @return Minutos E/O
	 */

	public double getMinutosEO() {
		return (double) this.GDAGMS().get(5);
	}

	/**
	 * Getter de los segundos E/O
	 * 
	 * @return Segundos E/O
	 */

	public double getSegundosEO() {
		return (double) this.GDAGMS().get(6);
	}

	/**
	 * Getter de la direccion longitudinal(puede ser Este u Oeste)
	 * 
	 * @return Direccion Longitudinal(solo puede ser E ó O)
	 */

	public char getEsteOeste() {
		return (char) this.GDAGMS().get(7);
	}

}

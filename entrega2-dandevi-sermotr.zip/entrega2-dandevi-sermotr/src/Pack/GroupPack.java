package Pack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import Bike.AdultBike;
import Bike.Bike;
import Bike.ChildBike;

public class GroupPack extends Pack {

	/**
	 * Constructor del pack de grupo
	 * 
	 * @param bicis
	 *            Bicis del pack,debe haber un mínimo de 10 bicis en el pack
	 * @see Pack
	 */

	public GroupPack(Bike[] bicis) {
		super(bicis);
		assert (bicis.length >= 10);
	}

	/**
	 * Obtiene la fianza de pack de grupo
	 * 
	 * @see Resource
	 * @return Fianza del pack de grupo, que es un 20 por ciento menor que el
	 *         precio estandar
	 */

	@Override
	public double getDepositToPay(double deposit) {
		double suma = 0;
		for (int i = 0; i < this.getBicis().length; i++) {
			suma = suma + this.getBicis()[i].getDepositToPay(deposit);
		}
		return suma * 0.8;
	}

	/**
	 * Borra una bici del pack de bicis,siempre que no deje el pack con menos de
	 * 10 bicis
	 * 
	 * @param bici
	 *            a borrar
	 */

	public void borraBici(Bike bici) {
		assert (this.getBicis().length > 10);
		super.borraBici(bici);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GroupPack [bicis=" + super.getBicis() +", getBicis()="
				+ Arrays.toString(getBicis()) + ", getCantidadBicis()=" + getCantidadBicis() + "]";
	}

}

package Pack;

import java.util.Arrays;
import Bike.Bike;
import Bike.ChildBike;

public class FamilyPack extends Pack {

	/**
	 * Constructor del pack familiar
	 * 
	 * @param bicis
	 *            Cantidad de bicis del pack,tiene que haber un minimo de cuatro
	 *            bicis,dos de ellas bicis de nino
	 * @see Pack
	 */

	public FamilyPack(Bike[] bicis) {
		super(bicis);
		assert (bicis.length >= 4);
		assert (cuantasBicisNino() >= 2);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FamilyPack [bicis=" + super.getBicis() + ", getBicis()="
				+ Arrays.toString(getBicis()) + ", getCantidadBicis()=" + getCantidadBicis() + "]";
	}

	/**
	 * Obtiene la fianza para packs familiares
	 * 
	 * @see Resource.Resource
	 * @return Fianza del pack familiar,que es un 50% del precio estandar
	 */

	@Override
	public double getDepositToPay(double deposit) {
		double suma = 0;
		for (int i = 0; i < this.getBicis().length; i++) {
			suma = suma + this.getBicis()[i].getDepositToPay(deposit);
		}
		return suma * 0.5;
	}

	/**
	 * Borra una bici del pack,solo lo permite si hay mas de 4 bici en total y
	 * mas de dos de ellas que sean de nino
	 * 
	 * @param bici
	 *            Bici a borrar
	 */

	@Override
	public void borraBici(Bike bici) {
		assert (this.getBicis().length > 4);
		assert (this.cuantasBicisNino() > 2);
		super.borraBici(bici);

	}

	/**
	 * Calcula las bicis de nino existentes en un pack
	 * 
	 * @return
	 */

	private int cuantasBicisNino() {
		int cont = 0;
		for (int i = 0; i < this.getCantidadBicis(); i++) {
			if (this.getBicis()[i] instanceof ChildBike)
				cont++;
		}
		return cont;
	}

}

package Pack;

import java.util.ArrayList;
import java.util.Arrays;

import Bike.Bike;
import Resource.Resource;

/**
 * @author Daniel de Vicente Garrote(dandevi)
 * @author Sergio Motrel Bajo(sermotr)
 */

public abstract class Pack implements Resource {

	private ArrayList<Bike> bicis;

	/**
	 * Constructor de la clase abstracta Pack
	 * 
	 * @param bicis
	 *            Cantidad de bicis en el pack(pueden ser de diferentes
	 *            tipos),no puede haber bicis repetidas
	 * 
	 */

	public Pack(Bike[] bicis) {
		if (bicis == null)
			throw new IllegalArgumentException();
		this.bicis = new ArrayList<Bike>();
		for (int i = 0; i < bicis.length; i++) {
			if (bicis[i] == null)
				throw new IllegalArgumentException();
			this.bicis.add(bicis[i]);
		}
		assert (bicisDistintas());
	}

	/**
	 * Comprueba que na haya bicis repetidas en el pack
	 * 
	 * @return false si hay dos bicis iguales,true en caso contrario
	 */
	private boolean bicisDistintas() {
		for (int i = 0; i < bicis.size(); i++) {
			for (int j = 0; j < bicis.size(); j++) {
				if (i != j) {
					if (bicis.get(i).equals(bicis.get(j))) {
						return false;
					}
				}
			}
		}
		return true;
	}
	
	/**
	 * Permite comparar dos packs para ver si tienen las mismas bicis o no(tiene en cuenta si estan desoredenadas una respecto de la otra)
	 * @param bicis1 
	 * @return
	 */

	private boolean mismasBicis(Object obj) {
		obj=(Pack)obj;
		if (((Pack) obj).getBicis().length != this.bicis.size()) {
			return false;
		} else {
			int cont = ((Pack) obj).getBicis().length;
			for (int i = 0; i < ((Pack) obj).getBicis().length; i++) {
				for (int j = 0; j < this.bicis.size(); j++) {
					if (((Pack) obj).getBicis()[i].equals(bicis.get(j))) {
						cont--;
					}
				}
			}
			return cont == 0 ? true : false;
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 * Incluye el mismasBicis
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pack other = (Pack) obj;
		if(this.mismasBicis(obj))
			return true;
		if (bicis == null) {
			if (other.bicis != null)
				return false;
		} else if (!bicis.equals(other.bicis))
			return false;
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Pack [bicis=" + bicis + ", bicisDistintas()=" + bicisDistintas() + ", getBicis()="
				+ Arrays.toString(getBicis()) + ", getCantidadBicis()=" + getCantidadBicis() + "]";
	}

	/**
	 * Establece un factor de corrección a la fianza según el tipo de pack a
	 * escoger
	 * 
	 * @see Resource
	 * @return Fianza modificada,que será un numero positivo mayor que cero
	 */

	@Override
	public abstract double getDepositToPay(double deposit);

	/**
	 * Getter de bicis
	 * 
	 * @return Bicis del pack(hay un número mínimo de bicis diferente según el
	 *         pack)
	 */

	public Bike[] getBicis() {
		Bike[] res = new Bike[bicis.size()];
		return bicis.toArray(res);
	}

	/**
	 * 
	 * Devuelve la cantidad de bicis en el pack
	 * 
	 * @return Cantidad de bicis,que sera un numero entero positivo mayor de
	 *         cierta cantidad(depende del tipo de pack)
	 */

	public int getCantidadBicis() {
		return this.bicis.size();
	}

	/**
	 * Comprueba si hay una bici existente en un pack
	 * 
	 * @param bici
	 *            Bici a buscar
	 * @return true si existen dicha bici en el pack,false en caso contrario
	 */

	public boolean existe(Bike bici) {
		return (bicis.contains(bici)) ? true : false;
	}

	/**
	 * Anade una nueva bici al array de bicis del pack
	 * 
	 * @param bici
	 *            Bici a anadir
	 */

	public void anadirBici(Bike bici) {
		this.bicis.add(bici);
	}

	/**
	 * Borra una bici al pack(las normas de poder borrar varian en funcion del
	 * pack)
	 * 
	 * @param bici
	 *            Bici a borrar
	 */
	public void borraBici(Bike bici) {
		assert (this.existe(bici));
		bicis.remove(bici);
	}
}

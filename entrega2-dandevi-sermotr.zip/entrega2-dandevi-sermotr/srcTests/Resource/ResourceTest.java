package Resource;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import Bike.AdultBike;
import Bike.Bike;
import Bike.ChildBike;
import Bike.ElectricBike;
import CityBikeSystem.CityBikeSystem;
import Pack.FamilyPack;
import Pack.GroupPack;

/**
 * @author Daniel de Vicente Garrote(dandevi)
 * @author Sergio Motrel Bajo(sermotr)
 */

public class ResourceTest {

	public static final double ErrorAdmisible = 0.01;

	CityBikeSystem sistema;

	Resource biciadulto;
	Resource bicinino;
	Resource bicielectrica;
	Resource bici1;
	Resource bici2;
	Resource bici3;
	Resource bici4;
	Resource bici5;
	Resource bici6;
	Resource bici7;

	Bike[] bicisgrupo;

	Bike[] bicisfamilia;

	Resource packgrupo;

	Resource packfamilia;

	@Before
	public void setUp() {

		sistema = new CityBikeSystem(null, 0.5);

		biciadulto = new AdultBike("M", "123455", "Marca", "Modelo", 25.75, 4, 5);
		bicinino = new ChildBike("16", "147258", "Marca", "Modelo", 15.2, 2, 2);
		bicielectrica = new ElectricBike("XL", "123123", "Marca", "Modelo", 30, 1, 1, 15, 24, 500);
		bici1 = new AdultBike("M", "123456", "Marca", "Modelo", 25.75, 4, 5);
		bici2 = new AdultBike("M", "123457", "Marca", "Modelo", 25.75, 4, 5);
		bici3 = new AdultBike("M", "123458", "Marca", "Modelo", 25.75, 4, 5);
		bici4 = new AdultBike("M", "123459", "Marca", "Modelo", 25.75, 4, 5);
		bici5 = new AdultBike("M", "123450", "Marca", "Modelo", 25.75, 4, 5);
		bici6 = new ChildBike("18", "147258", "Marca", "Modelo", 15.2, 2, 2);
		bici7 = new ElectricBike("XL", "123abc", "Marca", "Modelo", 30, 1, 1, 15, 24, 500);

		bicisgrupo = new Bike[10];
		
		bicisfamilia = new Bike[4];

		bicisgrupo[0] = (Bike) biciadulto;
		bicisgrupo[1] = (Bike) bicinino;
		bicisgrupo[2] = (Bike) bicielectrica;
		bicisgrupo[3] = (Bike) bici1;
		bicisgrupo[4] = (Bike) bici2;
		bicisgrupo[5] = (Bike) bici3;
		bicisgrupo[6] = (Bike) bici4;
		bicisgrupo[7] = (Bike) bici5;
		bicisgrupo[8] = (Bike) bici6;
		bicisgrupo[9] = (Bike) bici7;

		bicisfamilia[0] = (Bike) biciadulto;
		bicisfamilia[1] = (Bike) bicinino;
		bicisfamilia[2] = (Bike) bici6;
		bicisfamilia[3] = (Bike) bici7;

		packgrupo = new GroupPack(bicisgrupo);

		packfamilia = new FamilyPack(bicisfamilia);
	}

	@After
	public void tearDown() {
		sistema = null;

		biciadulto = null;
		bicinino = null;
		bicielectrica = null;
		bici1 = null;
		bici2 = null;
		bici3 = null;
		bici4 = null;
		bici5 = null;
		bici6 = null;
		bici7 = null;

		bicisgrupo = null;

		bicisfamilia = null;

		packgrupo = null;

		packfamilia = null;
	}

	@Test
	public void testGetDepositToPayAdulto() {
		assertEquals(biciadulto.getDepositToPay(sistema.getFianza()), 0.5, ErrorAdmisible);
	}

	@Test(expected = AssertionError.class)
	public void testGetDepositToPayAdultoError() {
		assertEquals(biciadulto.getDepositToPay(sistema.getFianza()), 0.425, ErrorAdmisible);
	}

	@Test
	public void testGetDepositToPayNino() {
		assertEquals(bicinino.getDepositToPay(sistema.getFianza()), 0.425, ErrorAdmisible);
	}

	@Test(expected = AssertionError.class)
	public void testGetDepositToPayNinoError() {
		assertEquals(bicinino.getDepositToPay(sistema.getFianza()), 0.5, ErrorAdmisible);
	}

	@Test
	public void testGetDepositToPayElectrica() {
		assertEquals(bicielectrica.getDepositToPay(sistema.getFianza()), 0.62, ErrorAdmisible);
	}

	@Test(expected = AssertionError.class)
	public void testGetDepositToPayElectricaError() {
		assertEquals(bicielectrica.getDepositToPay(sistema.getFianza()), 0.5, ErrorAdmisible);
	}

	@Test
	public void testGetDepositToPayGrupo() {
		assertEquals(packgrupo.getDepositToPay(sistema.getFianza()), 4.072, ErrorAdmisible);
	}

	@Test(expected = AssertionError.class)
	public void testGetDepositToPayGrupoError() {
		assertEquals(packgrupo.getDepositToPay(sistema.getFianza()), 4.2, ErrorAdmisible);
	}

	@Test
	public void testGetDepositToPayFamilia() {
		assertEquals(packfamilia.getDepositToPay(sistema.getFianza()), 0.9850000000000001, ErrorAdmisible);
	}

	@Test(expected = AssertionError.class)
	public void testGetDepositToPayFamiliaError() {
		assertEquals(packfamilia.getDepositToPay(sistema.getFianza()), 1.576, ErrorAdmisible);
	}

}

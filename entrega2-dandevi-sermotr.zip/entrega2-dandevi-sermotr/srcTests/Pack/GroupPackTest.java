package Pack;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import Bike.AdultBike;
import Bike.Bike;
import CityBikeSystem.CityBikeSystem;

/**
 * @author Daniel de Vicente Garrote(dandevi)
 * @author Sergio Motrel Bajo(sermotr)
 */

public class GroupPackTest {

	public static final double ErrorAdmisible = 0.01;

	CityBikeSystem sistema;

	AdultBike bici1;
	AdultBike bici2;
	AdultBike bici3;
	AdultBike bici4;
	AdultBike bici5;
	AdultBike bici6;
	AdultBike bici7;
	AdultBike bici8;
	AdultBike bici9;
	AdultBike bici10;
	AdultBike bici11;
	AdultBike bici12;

	Bike[] bicis;

	Bike[] bicis2;

	GroupPack pack;

	GroupPack pack2;

	@Before
	public void setUp() {

		sistema = new CityBikeSystem(null, 0.5);

		bici1 = new AdultBike("L", "123456", "Marca", "Modelo", 25.75, 3, 3);
		bici2 = new AdultBike("L", "123457", "Marca", "Modelo", 25.75, 3, 3);
		bici3 = new AdultBike("L", "123458", "Marca", "Modelo", 25.75, 3, 3);
		bici4 = new AdultBike("L", "123459", "Marca", "Modelo", 25.75, 3, 3);
		bici5 = new AdultBike("L", "123450", "Marca", "Modelo", 25.75, 3, 3);
		bici6 = new AdultBike("L", "123451", "Marca", "Modelo", 25.75, 3, 3);
		bici7 = new AdultBike("L", "123452", "Marca", "Modelo", 25.75, 3, 3);
		bici8 = new AdultBike("L", "123453", "Marca", "Modelo", 25.75, 3, 3);
		bici9 = new AdultBike("L", "123454", "Marca", "Modelo", 25.75, 3, 3);
		bici10 = new AdultBike("L", "123455", "Marca", "Modelo", 25.75, 3, 3);
		bici11 = new AdultBike("M", "654321", "Marca", "Modelo", 25.75, 3, 3);
		bici12 = new AdultBike("M", "654321", "Marca", "Modelo", 25.75, 3, 3);

		bicis = new Bike[10];

		bicis[0] = bici1;
		bicis[1] = bici2;
		bicis[2] = bici3;
		bicis[3] = bici4;
		bicis[4] = bici5;
		bicis[5] = bici6;
		bicis[6] = bici7;
		bicis[7] = bici8;
		bicis[8] = bici9;
		bicis[9] = bici10;

		bicis2 = new Bike[11];

		bicis2[0] = bici1;
		bicis2[1] = bici2;
		bicis2[2] = bici3;
		bicis2[3] = bici4;
		bicis2[4] = bici5;
		bicis2[5] = bici6;
		bicis2[6] = bici7;
		bicis2[7] = bici8;
		bicis2[8] = bici9;
		bicis2[9] = bici10;
		bicis2[10] = bici11;

		pack = new GroupPack(bicis);

		pack2 = new GroupPack(bicis2);
	}

	@After
	public void tearDown() {

		sistema = null;

		bici1 = null;
		bici2 = null;
		bici3 = null;
		bici4 = null;
		bici5 = null;
		bici6 = null;
		bici7 = null;
		bici8 = null;
		bici9 = null;
		bici10 = null;
		bici11 = null;
		bici12 = null;

		bicis = null;

		bicis2 = null;

		pack = null;
		pack2 = null;
	}

	@Test
	public void testGetDepositToPay() {
		assertEquals(pack.getDepositToPay(sistema.getFianza()), 4, ErrorAdmisible);
	}

	@Test(expected = AssertionError.class)
	public void testGetDepositToPayError() {
		assertEquals(pack.getDepositToPay(sistema.getFianza()), 2.5, ErrorAdmisible);
	}

	@Test
	public void testGetBicis() {
		assertSame(pack.getBicis()[0], bici1);
		assertSame(pack.getBicis()[1], bici2);
		assertSame(pack.getBicis()[2], bici3);
		assertSame(pack.getBicis()[3], bici4);
		assertSame(pack.getBicis()[4], bici5);
		assertSame(pack.getBicis()[5], bici6);
		assertSame(pack.getBicis()[6], bici7);
		assertSame(pack.getBicis()[7], bici8);
		assertSame(pack.getBicis()[8], bici9);
		assertSame(pack.getBicis()[9], bici10);
	}

	@Test(expected = AssertionError.class)
	public void testGetBicisError() {
		assertSame(pack.getBicis()[0], bici2);
	}

	@Test
	public void testAnadeBici() {
		pack.anadirBici(bici11);
		assertEquals(pack.getCantidadBicis(), 11);
	}

	@Test(expected = AssertionError.class)
	public void testAnadeBiciExistente() {
		pack.anadirBici(bici10);
		assertEquals(pack.getCantidadBicis(), 10);
	}

	@Test
	public void testBorraBici() {
		pack2.borraBici(bici9);
		assertEquals(pack2.getCantidadBicis(), 10);
	}

	@Test(expected = AssertionError.class)
	public void testBorraBiciCon10Bicis() {
		pack.borraBici(bici9);
	}

	@Test(expected = AssertionError.class)
	public void testBorraBiciInexistente() {
		pack.anadirBici(bici12);
		assertEquals(pack.getCantidadBicis(), 10);
	}

	@Test
	public void testEquals() {
		assertEquals(pack, (new GroupPack(bicis)));
	}

	@Test
	public void testEqualsDesorden() {
		Bike[] bicisDesorden = { bici4, bici6, bici8, bici10, bici2, bici1, bici3, bici5, bici7, bici9 };
		assertTrue(pack.equals(new GroupPack(bicisDesorden)));
	}

	@Test(expected = AssertionError.class)
	public void testEqualsError() {
		assertEquals(pack, (new GroupPack(bicis2)));
	}

	@Test(expected = AssertionError.class)
	public void testEqualsOrdenDistinto() {
		Bike[] bicisDesorden = { bici4, bici6, bici8, bici10, bici2, bici1, bici3, bici5, bici7, bici9, bici11 };
		assertTrue(pack.equals(new GroupPack(bicisDesorden)));
	}

	@Test
	public void testToString() {
		assertNotNull(pack.toString());
		assertNotEquals(pack.toString(), "");
	}

	@Test(expected = AssertionError.class)
	public void testToStringError() {
		assertEquals(pack, pack.toString());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testPackNulo() {
		GroupPack packNulo = new GroupPack(null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testPackElementoNulo() {
		Bike[] bicisVacio = { bici4, bici6, bici8, bici10, bici2, bici1, bici3, bici5, null, bici7, bici9 };
		GroupPack packElementoNulo = new GroupPack(bicisVacio);
	}

}

/**
 * 
 * @author Daniel de Vicente Garrote(dandevi)
 * @author Sergio Motrel Bajo(sermotr)
 *
 */

package CityBikeSystem;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import org.junit.Test;
import CityBikeParkingPoint.CityBikeParkingPoint;
import Coordenadas.Coordenadas;

public class CityBikeSystemTest {
	
	final double ERRORESPERADO=0.01;
	double fianza=0.5;
	
	Coordenadas gd1=new Coordenadas(125,76);
	Coordenadas gd2=new Coordenadas(65,-1);
	Coordenadas gd3=new Coordenadas(-23,97);
	
	boolean[] anclaje1={true,true,false};
	boolean[] anclaje2={true,true,true,true};
	boolean[] anclaje3={false,false,true,true,false};
	
	CityBikeParkingPoint punto1=new CityBikeParkingPoint(gd1, 123456, anclaje1);
	CityBikeParkingPoint punto2=new CityBikeParkingPoint(gd2, 159357, anclaje2);
	CityBikeParkingPoint punto3=new CityBikeParkingPoint(gd3, 147258, anclaje3);
	
	ArrayList<CityBikeParkingPoint> listaPuntos=new ArrayList<CityBikeParkingPoint>(Arrays.asList(punto1,punto2,punto3));
	ArrayList<CityBikeParkingPoint> listaPuntosError=new ArrayList<CityBikeParkingPoint>(Arrays.asList(punto1,punto2));
	CityBikeSystem sistema=new CityBikeSystem(listaPuntos,fianza);
	
	@Test
	public void getAPuntosTest(){
		assertSame(sistema.getAPuntos(),listaPuntos);
	}
	
	@Test(expected=AssertionError.class)
	public void getAPuntosTestError(){
		assertSame(sistema.getAPuntos(),listaPuntosError);
	}
	
	@Test
	public void nuevoPuntoTest() {
		CityBikeParkingPoint punto4=new CityBikeParkingPoint(gd3, 123456, anclaje3);
		sistema.nuevoPunto(punto4);
		assertEquals(sistema.getAPuntos().size(),4);
	}
	
	@Test(expected=AssertionError.class)
	public void nuevoPuntoTestError() {
		CityBikeParkingPoint punto4=new CityBikeParkingPoint(gd3, 123456, anclaje3);
		sistema.nuevoPunto(punto4);
		assertEquals(sistema.getAPuntos().size(),3);
	}
	
	@Test
	public void borraPuntoTest(){
		int idBorrar=punto3.getId();
		sistema.borraPunto(idBorrar);
		assertEquals(sistema.getAPuntos().size(),2);
	}
	
	@Test(expected=AssertionError.class)
	public void borraPuntoTestError(){
		int idBorrar=punto3.getId();
		sistema.borraPunto(idBorrar);
		assertEquals(sistema.getAPuntos().size(),3);
	}
	//No cambia la fianza
	@Test
	public void modFianzaTest(){
		sistema.modFianza(0.8);
		assertEquals(sistema.getFianza(),0.8,ERRORESPERADO);
	}
	
	@Test(expected=AssertionError.class)
	public void modFianzaTestError(){
		sistema.modFianza(0.8);
		assertEquals(sistema.getFianza(),0.5,ERRORESPERADO);
	}
	
	@Test(expected=AssertionError.class)
	public void modFianzaTestErrorParamNoValido(){
		sistema.modFianza(-0.3);
		assertEquals(sistema.getFianza(),0.5,ERRORESPERADO);
	}
	
	@Test(expected=AssertionError.class)
	public void modFianzaTestErrorValorCero(){
		sistema.modFianza(0);
		assertEquals(sistema.getFianza(),0.5,ERRORESPERADO);
	}
	
	@Test
	public void puntosConBiciTest(){
		assertSame(sistema.puntosConBici()[0],listaPuntos.get(0));
		assertSame(sistema.puntosConBici()[1],listaPuntos.get(1));
		assertSame(sistema.puntosConBici()[2],listaPuntos.get(2));
	}
	
	@Test(expected=AssertionError.class)
	public void puntosConBiciTestError(){
		assertSame(sistema.puntosConBici()[0],listaPuntosError.get(0));
		assertSame(sistema.puntosConBici()[1],listaPuntosError.get(0));
	}
	
	@Test
	public void puntosLibresTest(){
		assertSame(sistema.puntosLibres()[0],listaPuntos.get(0));
		assertNotSame(sistema.puntosLibres()[1],listaPuntos.get(1));
	}
	
	@Test(expected=AssertionError.class)
	public void puntosLibresTestError(){
		assertSame(sistema.puntosLibres()[0],listaPuntos.get(0));
		assertSame(sistema.puntosLibres()[1],listaPuntos.get(1));
	}
	
	@Test
	public void puntoEnRadioTest(){
		double[] pos={60,60};
		assertEquals(sistema.puntoEnRadio(8000, pos).get(0),punto1);
	}
	
	@Test
	public void puntoEnRadioTestDistanciaExacta(){
		double[] pos={60,60};
		assertEquals(sistema.puntoEnRadio(7408, pos).get(1),punto2);
	}
	
	@Test(expected=IndexOutOfBoundsException.class)
	public void puntoEnRadioTestError(){
		double[] pos={60,60};
		assertEquals(sistema.puntoEnRadio(8000, pos).get(2),punto3);
	}
	
	

}

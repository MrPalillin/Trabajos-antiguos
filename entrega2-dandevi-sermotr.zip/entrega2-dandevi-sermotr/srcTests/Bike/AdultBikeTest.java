package Bike;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import CityBikeSystem.CityBikeSystem;

/**
 * @author Daniel de Vicente Garrote(dandevi)
 * @author Sergio Motrel Bajo(sermotr)
 */

public class AdultBikeTest {

	public static final double ErrorAdmisible = 0.01;

	CityBikeSystem sistema;
	AdultBike bici;
	AdultBike bici2;
	AdultBike bici3;

	@Before
	public void setUp() {
		sistema = new CityBikeSystem(null, 0.5);
		bici = new AdultBike("L", "123456", "Marca", "Modelo", 25.75, 3, 3);
		bici2 = new AdultBike("M", "123456", "Marca", "Modelo", 25.75, 3, 3);
		bici3 = new AdultBike("L", "123456", "Marca", "Modelo", 25.75, 3, 3);
	}

	@After
	public void tearDown() {
		sistema = null;
		bici = null;
		bici2 = null;
		bici3 = null;
	}

	@Test
	public void testGetDepositToPay() {
		assertEquals(bici.getDepositToPay(sistema.getFianza()), 0.5, ErrorAdmisible);
	}

	@Test(expected = AssertionError.class)
	public void testGetDepositToPayError() {
		assertEquals(bici.getDepositToPay(sistema.getFianza()), 0.425, ErrorAdmisible);
	}

	@Test
	public void testGetTalla() {
		assertEquals(bici.getTalla(), "L");
	}

	@Test(expected = AssertionError.class)
	public void testGetTallaError() {
		assertEquals(bici.getTalla(), "M");
	}
	
	@Test(expected = AssertionError.class)
	public void testGetTallaDeNino() {
		assertEquals(bici.getTalla(), "20");
	}

	@Test(expected = AssertionError.class)
	public void testGetTallaInexistente() {
		assertEquals(bici.getTalla(), "XS");
	}

	@Test
	public void testGetId() {
		assertEquals(bici.getId(), "123456");
	}

	@Test(expected = AssertionError.class)
	public void testGetIdError() {
		assertEquals(bici.getId(), "45g5g14");
	}

	@Test
	public void testGetMarca() {
		assertEquals(bici.getMarca(), "Marca");
	}

	@Test(expected = AssertionError.class)
	public void testGetMarcaError() {
		assertEquals(bici.getMarca(), "Modelo");
	}

	@Test
	public void testGetModelo() {
		assertEquals(bici.getModelo(), "Modelo");
	}

	@Test(expected = AssertionError.class)
	public void testGetModeloError() {
		assertEquals(bici.getModelo(), "Marca");
	}

	@Test
	public void testGetPeso() {
		assertEquals(bici.getPeso(), 25.75, ErrorAdmisible);
	}

	@Test(expected = AssertionError.class)
	public void testGetPesoError() {
		assertEquals(bici.getPeso(), -15, ErrorAdmisible);
	}
	
	@Test(expected = AssertionError.class)
	public void testGetPesoCero() {
		assertEquals(bici.getPeso(), 0, ErrorAdmisible);
	}
	
	@Test(expected = AssertionError.class)
	public void testGetPesoCasiNegativo() {
		assertEquals(bici.getPeso(), -5.25, ErrorAdmisible);
	}

	@Test
	public void testGetNumPinones() {
		assertEquals(bici.getNumPinones(), 3);
	}

	@Test(expected = AssertionError.class)
	public void testGetNumPinonesError() {
		assertEquals(bici.getNumPinones(), -1);
	}
	
	@Test(expected = AssertionError.class)
	public void testGetNumPinonesCero() {
		AdultBike biciError=new AdultBike("L", "123456", "Marca", "Modelo", 25.75, 0, 3);
	}
	
	@Test(expected = AssertionError.class)
	public void testGetNumPinonesNegativo() {
		AdultBike biciError=new AdultBike("L", "123456", "Marca", "Modelo", 25.75, -1, 3);
	}
	
	@Test
	public void testGetNumPinonesUno() {
		AdultBike biciError=new AdultBike("L", "123456", "Marca", "Modelo", 25.75, 1, 3);
	}

	@Test
	public void testGetNumPlatos() {
		assertEquals(bici.getNumPlatos(), 3);
	}

	@Test(expected = AssertionError.class)
	public void testGetNumPlatosError() {
		assertEquals(bici.getNumPlatos(), -2);
	}
	
	@Test(expected = AssertionError.class)
	public void testGetNumPlatosCero() {
		AdultBike biciError=new AdultBike("L", "123456", "Marca", "Modelo", 25.75, 4, 0);
	}
	
	@Test(expected = AssertionError.class)
	public void testGetNumPlatosNegativo() {
		AdultBike biciError=new AdultBike("L", "123456", "Marca", "Modelo", 25.75, 4, -5);
	}
	
	@Test
	public void testGetNumPlatosUno() {
		AdultBike biciError=new AdultBike("L", "123456", "Marca", "Modelo", 25.75, 1, 1);
	}

	@Test
	public void testEquals() {
		assertTrue(bici.equals(bici3));
	}

	@Test(expected = AssertionError.class)
	public void testEqualsError() {
		assertTrue(bici.equals(bici2));
	}

	@Test
	public void testToString() {
		assertNotNull(bici.toString());
		assertNotEquals(bici.toString(),"");
	}

	@Test(expected = AssertionError.class)
	public void testToStringError() {
		assertEquals(bici.toString(), "Bike []");
	}

}

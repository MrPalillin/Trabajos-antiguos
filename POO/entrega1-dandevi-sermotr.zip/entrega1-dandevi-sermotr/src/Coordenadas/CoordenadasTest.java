/**
 * 
 * @author Daniel de Vicente Garrote(dandevi)
 * @author Sergio Motrel Bajo(sermotr)
 *
 */

package Coordenadas;

import static org.junit.Assert.*;

import org.junit.Test;

public class CoordenadasTest {

	Coordenadas gd = new Coordenadas(125.21, -75.1);
	Coordenadas gms = new Coordenadas('N', 60, 45, 45, 'O', 25, 15, 20);
	final double ERRORESPERADO = 0.1;

	@Test
	public void GMSAGDLatTest() {
		Coordenadas prueba = new Coordenadas(60.762, -25.25);
		assertEquals(gms.GMSAGDLat(gms.getNorteSur(), gms.getGradosNS(), gms.getMinutosNS(), gms.getSegundosNS()),prueba.getLat(),ERRORESPERADO);
	}
	
	@Test
	public void GMSAGDLonTest() {
		Coordenadas prueba = new Coordenadas(60.762, -25.25);
		assertEquals(gms.GMSAGDLon(gms.getEsteOeste(), gms.getGradosEO(), gms.getMinutosEO(), gms.getSegundosEO()),prueba.getLon(),ERRORESPERADO);
	}

	@Test(expected = AssertionError.class)
	public void GMSAGDLatTestError() {
		Coordenadas prueba = new Coordenadas(-60.762, 25.25);
		assertEquals(gms.GMSAGDLat(gms.getNorteSur(), gms.getGradosNS(), gms.getMinutosNS(), gms.getSegundosNS()),prueba.getLat(),ERRORESPERADO);
	}
	
	@Test(expected = AssertionError.class)
	public void GMSAGDLonTestError() {
		Coordenadas prueba = new Coordenadas(-60.762, 25.25);
		assertEquals(gms.GMSAGDLon(gms.getEsteOeste(), gms.getGradosEO(), gms.getMinutosEO(), gms.getSegundosEO()),prueba.getLon(),ERRORESPERADO);
	}

	@Test
	public void GDAGMSTest() {
		Coordenadas prueba = new Coordenadas('N', 125, 12, 35, 'O', 75, 6, 0);
		assertEquals((double)gd.GDAGMS().get(4), prueba.getGradosEO(), ERRORESPERADO);
		assertEquals((double)gd.GDAGMS().get(5), prueba.getMinutosEO(), ERRORESPERADO);
		assertEquals((double)gd.GDAGMS().get(6), prueba.getSegundosEO(), ERRORESPERADO);
		assertEquals((double)gd.GDAGMS().get(0), prueba.getGradosNS(), ERRORESPERADO);
		assertEquals((double)gd.GDAGMS().get(1), prueba.getMinutosNS(), ERRORESPERADO);
		assertEquals((double)gd.GDAGMS().get(2), prueba.getSegundosNS(), ERRORESPERADO);
	}

	@Test(expected = AssertionError.class)
	public void GDAGMSTestError() {
		Coordenadas prueba = new Coordenadas('N', 120, 0, 0, 'O', 75, 7, 12);
		assertEquals((double)gd.GDAGMS().get(4), prueba.getGradosEO(), ERRORESPERADO);
		assertEquals((double)gd.GDAGMS().get(5), prueba.getMinutosEO(), ERRORESPERADO);
		assertEquals((double)gd.GDAGMS().get(6), prueba.getSegundosEO(), ERRORESPERADO);
		assertEquals((double)gd.GDAGMS().get(0), prueba.getGradosNS(), ERRORESPERADO);
		assertEquals((double)gd.GDAGMS().get(1), prueba.getMinutosNS(), ERRORESPERADO);
		assertEquals((double)gd.GDAGMS().get(2), prueba.getSegundosNS(), ERRORESPERADO);
	}

	@Test
	public void getLatTest() {
		assertEquals(gd.getLat(), 125.21, ERRORESPERADO);
	}

	@Test(expected = AssertionError.class)
	public void getLatTestError() {
		assertEquals(gd.getLat(), 125, ERRORESPERADO);
	}

	@Test
	public void getLonTest() {
		assertEquals(gd.getLon(), -75.12, ERRORESPERADO);
	}

	@Test(expected = AssertionError.class)
	public void getLonTestError() {
		assertEquals(gd.getLon(), 75, ERRORESPERADO);
	}

	@Test
	public void getGradosNSTest() {
		assertEquals(gms.getGradosNS(), 60, ERRORESPERADO);
	}

	@Test(expected = AssertionError.class)
	public void getGradosNSTestError() {
		assertEquals(gms.getGradosNS(), 40, ERRORESPERADO);
	}

	@Test
	public void getMinutosNSTest() {
		assertEquals(gms.getMinutosNS(), 45, ERRORESPERADO);
	}

	@Test(expected = AssertionError.class)
	public void getMinutosNSTestError() {
		assertEquals(gms.getGradosNS(), 40, ERRORESPERADO);
	}

	@Test
	public void getSegundosNSTest() {
		assertEquals(gms.getSegundosNS(), 45, ERRORESPERADO);
	}

	@Test(expected = AssertionError.class)
	public void getSegundosNSTestError() {
		assertEquals(gms.getSegundosNS(), 40, ERRORESPERADO);
	}
	
	@Test
	public void getNorteSurTest(){
		assertSame(gms.getNorteSur(),'N');
	}
	
	@Test(expected=AssertionError.class)
	public void getNorteSurTestError(){
		assertSame(gms.getNorteSur(),'S');
	}
	
	@Test
	public void getEsteOesteTest(){
		assertSame(gms.getEsteOeste(),'O');
	}
	
	@Test(expected=AssertionError.class)
	public void getNorteEsteOesteError(){
		assertSame(gms.getEsteOeste(),'E');
	}

	@Test
	public void getGradosEOTest() {
		assertEquals(gms.getGradosEO(), 25, ERRORESPERADO);
	}

	@Test(expected = AssertionError.class)
	public void getGradosEOTestError() {
		assertEquals(gms.getGradosEO(), 5, ERRORESPERADO);
	}

	@Test
	public void getMinutosEOTest() {
		assertEquals(gms.getMinutosEO(), 15, ERRORESPERADO);
	}

	@Test(expected = AssertionError.class)
	public void getMinutosEOTestError() {
		assertEquals(gms.getMinutosEO(), 5, ERRORESPERADO);
	}

	@Test
	public void getSegundosEOTest() {
		assertEquals(gms.getSegundosEO(), 20, ERRORESPERADO);
	}

	@Test(expected = AssertionError.class)
	public void getSegundosEOTestError() {
		assertEquals(gms.getSegundosEO(), 40, ERRORESPERADO);
	}

}

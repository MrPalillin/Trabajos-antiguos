/**
 * 
 * @author Daniel de Vicente Garrote(dandevi)
 * @author Sergio Motrel Bajo(sermotr)
 *
 */

package CityBikeParkingPoint;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import org.junit.Test;

import CityBikeSystem.CityBikeSystem;
import fabricante.externo.tarjetas.TarjetaMonedero;
import Coordenadas.Coordenadas;

public class CityBikeParkingPointTest<puntos> {

	final double ERRORESPERADO = 0.01;
	double fianza=0.5;
	double fianzaError=0.8;
	boolean[] anclaje = { true, false, true };
	
	Coordenadas ejemploGMS = new Coordenadas('S', 159, 30, 0, 'E', 27, 11, 59);
	Coordenadas errorGMS1 = new Coordenadas('N', 159, 30, 0, 'E', 27, 11, 59);
	Coordenadas errorGMS2 = new Coordenadas('S', 159, 30, 45, 'E', 27, 11, 59);
	
	Coordenadas gd = new Coordenadas(-159.5, 27.2);
	Coordenadas ejemploGD = new Coordenadas( -159.5, 27.20 );
	Coordenadas errorGD = new Coordenadas( 159, 27 );
	Coordenadas distanciaGD = new Coordenadas( -100, 75 );
	Coordenadas errorDistanciaGD = new Coordenadas( 150, 65 );
	
	CityBikeParkingPoint punto = new CityBikeParkingPoint(gd, 123456, anclaje);
	
	ArrayList<CityBikeParkingPoint> listaPuntos=new ArrayList<CityBikeParkingPoint>(Arrays.asList(punto));
	
	CityBikeSystem sistema=new CityBikeSystem(listaPuntos,fianza);
	
	TarjetaMonedero tarjeta = new TarjetaMonedero("A156Bv09_1zXo894", 2.0);
	TarjetaMonedero tarjetavacia = new TarjetaMonedero("A156Bv09_1zXo894", 0.0);
	
	@Test
	public void numAnclajesTest() {
		assertEquals(punto.numeroAnclajes(), 3);
	}

	@Test(expected = AssertionError.class)
	public void numAnclajesTestError() {
		assertEquals(punto.numeroAnclajes(), 2);
	}
	
	@Test
	public void getAnclajesTest(){
		boolean[] prueba={true,false,true};
		assertTrue(Arrays.equals(punto.getAnclajes(), prueba));
	}
	
	@Test(expected=AssertionError.class)
	public void getAnclajesTestError(){
		boolean[] prueba={true,false,false};
		assertTrue(Arrays.equals(punto.getAnclajes(), prueba));
	}
	
	@Test
	public void getEstadoAnclajeTest(){
		assertTrue(punto.getEstadoAnclaje(0));
	}
	
	@Test(expected=AssertionError.class)
	public void getEstadoAnclajeTestError(){
		assertTrue(punto.getEstadoAnclaje(1));
	}
	
	@Test
	public void getFianzaTest(){
		assertEquals(punto.getFianza(),fianza,ERRORESPERADO);
	}
	
	@Test(expected=AssertionError.class)
	public void getFianzaTestError(){
		assertEquals(punto.getFianza(),fianzaError,ERRORESPERADO);
	}
	
	@Test
	public void anclajesUsadosTest() {
		assertEquals(punto.anclajesUsados(), 2);
	}

	@Test(expected = AssertionError.class)
	public void anclajesUsadosTestError() {
		assertEquals(punto.anclajesUsados(), 1);
	}

	@Test
	public void posicionGMSTest() {
		assertSame(punto.getPosicionGMS().get(3), ejemploGMS.getNorteSur());
		assertSame(punto.getPosicionGMS().get(7), ejemploGMS.getEsteOeste());
		assertEquals((double)punto.getPosicionGMS().get(0), ejemploGMS.getGradosNS(),ERRORESPERADO);
		assertEquals((double)punto.getPosicionGMS().get(4), ejemploGMS.getGradosEO(),ERRORESPERADO);
		assertEquals((double)punto.getPosicionGMS().get(1), ejemploGMS.getMinutosNS(),ERRORESPERADO);
		assertEquals((double)punto.getPosicionGMS().get(5), ejemploGMS.getMinutosEO(),ERRORESPERADO);
		assertEquals((double)punto.getPosicionGMS().get(2), ejemploGMS.getSegundosNS(),ERRORESPERADO);
		assertEquals((double)punto.getPosicionGMS().get(6), ejemploGMS.getSegundosEO(),ERRORESPERADO);
	}

	@Test(expected = AssertionError.class)
	public void posicionGMSTestError1() {
		assertSame(punto.getPosicionGMS().get(0), errorGMS1.getNorteSur());
		assertSame(punto.getPosicionGMS().get(4), errorGMS1.getEsteOeste());
		assertEquals((double)punto.getPosicionGMS().get(1), errorGMS1.getGradosNS(),ERRORESPERADO);
		assertEquals((double)punto.getPosicionGMS().get(5), errorGMS1.getGradosEO(),ERRORESPERADO);
		assertEquals((double)punto.getPosicionGMS().get(2), errorGMS1.getMinutosNS(),ERRORESPERADO);
		assertEquals((double)punto.getPosicionGMS().get(6), errorGMS1.getMinutosEO(),ERRORESPERADO);
		assertEquals((double)punto.getPosicionGMS().get(3), errorGMS1.getSegundosNS(),ERRORESPERADO);
		assertEquals((double)punto.getPosicionGMS().get(7), errorGMS1.getSegundosEO(),ERRORESPERADO);
	}

	@Test(expected = AssertionError.class)
	public void posicionGMSTestError2() {
		assertSame(punto.getPosicionGMS().get(0), errorGMS2.getNorteSur());
		assertSame(punto.getPosicionGMS().get(4), errorGMS2.getEsteOeste());
		assertEquals((double)punto.getPosicionGMS().get(1), errorGMS2.getGradosNS(),ERRORESPERADO);
		assertEquals((double)punto.getPosicionGMS().get(5), errorGMS2.getGradosEO(),ERRORESPERADO);
		assertEquals((double)punto.getPosicionGMS().get(2), errorGMS2.getMinutosNS(),ERRORESPERADO);
		assertEquals((double)punto.getPosicionGMS().get(6), errorGMS2.getMinutosEO(),ERRORESPERADO);
		assertEquals((double)punto.getPosicionGMS().get(3), errorGMS2.getSegundosNS(),ERRORESPERADO);
		assertEquals((double)punto.getPosicionGMS().get(7), errorGMS2.getSegundosEO(),ERRORESPERADO);
	}

	@Test
	public void posicionGDTest() {
		assertEquals(punto.getPosicionGD().getLat(), ejemploGD.getLat(),ERRORESPERADO);
		assertEquals(punto.getPosicionGD().getLon(), ejemploGD.getLon(),ERRORESPERADO);

	}

	@Test(expected = AssertionError.class)
	public void posicionGDTestError() {
		assertEquals(punto.getPosicionGD().getLat(), errorGD.getLat(),ERRORESPERADO);
		assertEquals(punto.getPosicionGD().getLon(), errorGD.getLon(),ERRORESPERADO);	
	}

	@Test
	public void getIdTest() {
		assertEquals(punto.getId(), 123456);
	}

	@Test(expected = AssertionError.class)
	public void getIdTestError() {
		assertEquals(punto.getId(), 654321);
	}

	@Test
	public void prestarTest() {
		double saldo = tarjeta.getSaldoActual();
		saldo = saldo - punto.getFianza();
		punto.prestar(tarjeta, 0);
		assertEquals(tarjeta.getSaldoActual(), saldo, ERRORESPERADO);
		assertFalse(punto.getAnclajes()[0]);
	}

	@Test(expected = AssertionError.class)
	public void prestarTestErrorPos() {
		double saldo = tarjeta.getSaldoActual();
		saldo = saldo - punto.getFianza();
		punto.prestar(tarjeta, 1);
		assertEquals(tarjeta.getSaldoActual(), saldo, ERRORESPERADO);
		assertFalse(punto.getAnclajes()[2]);

	}

	@Test(expected = AssertionError.class)
	public void prestarTestErrorCantidad() {
		double saldo = tarjetavacia.getSaldoActual();
		saldo = saldo - punto.getFianza();
		punto.prestar(tarjetavacia, 0);
		assertEquals(tarjetavacia.getSaldoActual(), saldo, ERRORESPERADO);
		assertFalse(punto.getAnclajes()[1]);
	}

	@Test
	public void devolverTest() {
		double saldo = tarjeta.getSaldoActual();
		saldo = saldo + punto.getFianza();
		punto.devolver(tarjeta, 1);
		assertTrue(punto.getAnclajes()[1]);
		assertEquals(tarjeta.getSaldoActual(), saldo, ERRORESPERADO);
	}

	@Test(expected = AssertionError.class)
	public void devolverTestErrorPos() {
		double saldo = tarjeta.getSaldoActual();
		saldo = saldo + punto.getFianza();
		punto.devolver(tarjeta, 0);
		assertTrue(punto.getAnclajes()[1]);
		assertEquals(tarjeta.getSaldoActual(), saldo, ERRORESPERADO);
	}
	
	@Test(expected = AssertionError.class)
	public void devolverTestErrorCantidad() {
		double saldo = tarjeta.getSaldoActual();
		saldo = saldo + punto.getFianza();
		punto.devolver(tarjeta, 0);
		assertTrue(punto.getAnclajes()[1]);
		assertEquals(tarjeta.getSaldoActual(), saldo, ERRORESPERADO);
	}
	
	@Test
	public void distanciaDosPuntosTest() {
		double distancia = 5244;
		CityBikeParkingPoint destino = new CityBikeParkingPoint(distanciaGD, 159357, anclaje);
		assertEquals(punto.distanciaDosPuntos(destino), distancia, ERRORESPERADO);
	}

	@Test(expected = AssertionError.class)
	public void distanciaDosPuntosTestError() {
		double distancia = 5180;
		CityBikeParkingPoint destino = new CityBikeParkingPoint(errorDistanciaGD, 159357, anclaje);
		assertEquals(punto.distanciaDosPuntos(destino), distancia, ERRORESPERADO);
	}

}

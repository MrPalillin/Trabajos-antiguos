
/**
 * 
 * @author Daniel de Vicente Garrote(dandevi)
 * @author Sergio Motrel Bajo(sermotr)
 *
 */

package CityBikeParkingPoint;

import java.lang.Math;
import java.util.ArrayList;
import fabricante.externo.tarjetas.TarjetaMonedero;
import Coordenadas.Coordenadas;
import CityBikeSystem.CityBikeSystem;

//true=ocupado,false=libre

public class CityBikeParkingPoint {

	private Coordenadas posicion;
	private int id;
	private boolean[] anclajes;

	/**
	 * Constructor de la clase CityBikeParkingPoint
	 * 
	 * @param posicion
	 *            Coordenadas GPS del punto
	 * @param id Identificador del punto de aparcamiento
	 * @param anclajes Anclajes de aparcamiento de bicis del punto
	 */

	public CityBikeParkingPoint(Coordenadas posicion, int id, boolean[] anclajes) {

		this.posicion = posicion;
		this.id = id;
		this.anclajes = anclajes;
	}

	/**
	 * Devuelve el numero de anclajes de un punto de aparcamiento
	 * 
	 * @return Número de anclajes del punto,que es un número positivo mayor que cero
	 */

	public int numeroAnclajes() {
		return anclajes.length;
	}

	/**
	 * Devuelve los anclajes y el estado de cada uno
	 * 
	 * @return Lista de anclajes del punto de aparcamiento
	 */
	
	public boolean[] getAnclajes() {
		return anclajes;
	}

	/**
	 * Dado un identificador de modulo de anclaje devuelve el estado de
	 * este(libre u ocupado)
	 * 
	 * @param pos Identificador del módulo de anclaje,basado en su posicion en el array
	 * @return true(si hay una bici aparcada), o false(si no hay bici aparcada)
	 */

	public boolean getEstadoAnclaje(int pos) {
		return this.anclajes[pos];
	}

	/**
	 * Obtiene la fianza en base al sistema de puntos de aparcamiento al que
	 * está asociado
	 * 
	 * @return Fianza del punto de aparcamiento(la misma que los otros puntos de aparcamiento del mismo sistema)
	 */

	public double getFianza() {
		return CityBikeSystem.getFianza();
	}

	/**
	 * Devuelve el número de anclajes ocupados con bicis
	 * 
	 * @return Numero de anclajes ocupados
	 */

	public int anclajesUsados() {
		int cont = 0;
		for (int i = 0; i < anclajes.length; i++) {
			if (anclajes[i]) {
				cont++;
			}
		}
		return cont;
	}

	/**
	 * Devuelve la posicion del punto de aparcamiento en coordenadas decimales
	 * 
	 * @return Posicion del punto de aparcamiento en formato GD
	 */

	public Coordenadas getPosicionGD() {
		return this.posicion;
	}

	/**
	 * Devuelve la posición del punto de aparcamiento en coordenadas
	 * sexagesimales
	 * 
	 * @return Posicion del punto de aparcamiento en formato GMS
	 */

	public ArrayList<?> getPosicionGMS() {
		return posicion.GDAGMS();
	}

	/**
	 * Devuelve la id del punto de aparcamineto
	 * 
	 * @return Identificador del punto de aparcamiento
	 */

	public int getId() {
		return id;
	}

	/**
	 * Realiza el préstamo de una bicicleta a un usuario con tarjeta,liberando
	 * el punto de anclaje si la operacion es exitosa
	 * 
	 * @param tarjeta Tarjeta monedero con la que se paga la fianza
	 * @param pos Modulo de anclaje donde esta la bicicleta(anula la operacion si no hay bici)
	 */

	public void prestar(TarjetaMonedero tarjeta, int pos) {
		try {
			assert (pos >= 0);
			assert (pos < anclajes.length);
			assert (tarjeta.getSaldoActual() >= 0.5);
			assert (anclajes[pos]);
			tarjeta.descontarDelSaldo("6Z1y00Nm31aA-571", this.getFianza());
			anclajes[pos] = false;
		} catch (AssertionError e) {
		}
	}

	/**
	 * Devuelve una bicicleta a un punto de aparcamiento,devolviendo el dinero a
	 * la tarjeta y ocupando un anclaje si la operacion es exitosa
	 * 
	 * @param tarjeta Tarjeta monedero que recibe la fianza de vuelta
	 * @param pos Modulo de anclaje donde se devuelve la bicicleta(anula la operacion si ya hay una bici aparcada)
	 */

	public void devolver(TarjetaMonedero tarjeta, int pos) {
		try {
			assert (pos >= 0);
			assert (pos < anclajes.length);
			assert (!anclajes[pos]);
			tarjeta.recargaSaldo("A156Bv09_1zXo894", CityBikeSystem.getFianza());
			System.out.println(tarjeta.getSaldoActual());
			anclajes[pos] = true;
		} catch (AssertionError e) {
		}
	}

	/**
	 * Determina la distancia de un punto de aparcamiento con este otro
	 * 
	 * @param destino Punto de aparcamiento distante
	 * @return Distancia en kilometros del punto de aparcamiento con respecto a este
	 */

	public double distanciaDosPuntos(CityBikeParkingPoint destino) {

		double gdRes = 0;
		double a = 0;
		double c = 0;
		double dlat = Math.abs(destino.getPosicionGD().getLat() - posicion.getLat());
		dlat = Math.toRadians(dlat);
		double dlon = Math.abs(destino.getPosicionGD().getLon() - posicion.getLon());
		double r = 6371;
		dlon = Math.toRadians(dlon);
		a = (Math.sin(Math.pow((dlat / 2), 2))) + Math.cos(posicion.getLat())
				* Math.cos(destino.getPosicionGD().getLat()) * (Math.pow(Math.sin(dlon / 2), 2));
		c = 2 * Math.asin((Math.min(1, Math.sqrt(a))));
		gdRes = r * c;
		return Math.round(gdRes);
	}

}
